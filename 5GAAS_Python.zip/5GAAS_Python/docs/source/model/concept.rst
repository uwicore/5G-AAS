aas.model.concept - ConceptDescription and Dictionary
=====================================================

.. automodule:: basyx.aas.model.concept
      :members:
