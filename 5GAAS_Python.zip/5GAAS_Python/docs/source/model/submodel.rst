aas.model.submodel - Meta-model of the submodels and events
===========================================================

.. automodule:: basyx.aas.model.submodel
      :members:
