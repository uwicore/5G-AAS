aas.examples.data.example_concept_description - Create an example ConceptDescription
====================================================================================

.. automodule:: basyx.aas.examples.data.example_concept_description
      :members:
