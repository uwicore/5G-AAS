aas.examples.data.example_submodel_template - Create an Example Submodel Template
=================================================================================

.. automodule:: basyx.aas.examples.data.example_submodel_template
      :members:
