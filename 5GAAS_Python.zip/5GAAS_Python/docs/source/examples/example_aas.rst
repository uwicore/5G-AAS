aas.examples.data.example_aas - Create an example model.AssetAdministrationShell object
=======================================================================================

.. automodule:: basyx.aas.examples.data.example_aas
      :members:
