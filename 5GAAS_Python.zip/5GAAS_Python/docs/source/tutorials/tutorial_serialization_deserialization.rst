Tutorial: Serialization Deserialization
=======================================

.. _tutorial_serialization_deserialization:

.. literalinclude:: ../../../basyx/aas/examples/tutorial_serialization_deserialization.py
  :language: python
