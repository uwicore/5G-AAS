Tutorials for working with the Eclipse BaSyx Python SDK
=======================================================


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   tutorial_create_simple_aas
   tutorial_serialization_deserialization
   tutorial_storage
   tutorial_backend_couchdb
   tutorial_aasx
