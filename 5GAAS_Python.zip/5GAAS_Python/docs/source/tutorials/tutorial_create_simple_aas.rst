Tutorial: Create a Simple AAS
=============================

.. _tutorial_create_simple_aas:

.. literalinclude:: ../../../basyx/aas/examples/tutorial_create_simple_aas.py
  :language: python
