Tutorial: Backend Couchdb
=============================

.. _tutorial_backend_couchdb:

.. literalinclude:: ../../../basyx/aas/examples/tutorial_backend_couchdb.py
  :language: python
