Tutorial: Storage
=================

.. _tutorial_storage:

.. literalinclude:: ../../../basyx/aas/examples/tutorial_storage.py
  :language: python
