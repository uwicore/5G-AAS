adapter: Adapter of AAS-objects from and to different file-formats
==================================================================

.. automodule:: basyx.aas.adapter.__init__
      :members:

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   json
   xml
   aasx