.. Eclipse BaSyx Python SDK documentation master file, created by
   sphinx-quickstart on Tue Nov 10 15:09:27 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the Eclipse BaSyx Python SDK's documentation!
========================================================

.. toctree::
   :numbered:
   :maxdepth: 2
   :caption: Contents:

   tutorials/index
   model/index
   adapter/index
   backend/index
   examples/index
   compliance_tool/index
   util/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
