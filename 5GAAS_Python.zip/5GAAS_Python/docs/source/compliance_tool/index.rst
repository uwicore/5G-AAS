aas.compliance_tool - Tool for Creating and Checking JSON, XML and AASX Files' compliance
=========================================================================================

.. argparse::
    :module: basyx.aas.compliance_tool.cli
    :func: parse_cli_arguments
    :prog: cli

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   compliance_check_aasx
   compliance_check_json
   compliance_check_xml
   state_manager
