aas.compliance_tool.state_manager - Store LogRecords in a Compliance Check of the Compliance Tool
=================================================================================================

.. automodule:: basyx.aas.compliance_tool.state_manager
      :members:
